__turbopack_load_page_chunks__("/", [
  "static/chunks/7a34bb1fa340396b.js",
  "static/chunks/703451e762e00579.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/turbopack-ffd3566131617199.js"
])
