__turbopack_load_page_chunks__("/_error", [
  "static/chunks/7f84e238cf01cacf.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/turbopack-f4e1c98853a69c1a.js"
])
