__turbopack_load_page_chunks__("/api-docs", [
  "static/chunks/79853526f4a3dbd5.js",
  "static/chunks/703451e762e00579.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/6c804ac4ce966313.css",
  "static/chunks/turbopack-905caac1449edc9d.js"
])
