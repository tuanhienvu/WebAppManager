__turbopack_load_page_chunks__("/login", [
  "static/chunks/ef2a36a82d72f307.js",
  "static/chunks/731d714d75201630.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/turbopack-a2f05df369e12ccb.js"
])
