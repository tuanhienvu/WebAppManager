__turbopack_load_page_chunks__("/audit-logs", [
  "static/chunks/9ad373a50c4973e2.js",
  "static/chunks/703451e762e00579.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/turbopack-6bd715b5d438246e.js"
])
