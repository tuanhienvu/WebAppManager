__turbopack_load_page_chunks__("/settings", [
  "static/chunks/07ca223b8a905559.js",
  "static/chunks/703451e762e00579.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/turbopack-82ee580cef3c0464.js"
])
