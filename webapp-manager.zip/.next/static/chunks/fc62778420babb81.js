__turbopack_load_page_chunks__("/_app", [
  "static/chunks/b0ad044e9531f801.js",
  "static/chunks/42dc5ea08fc980c5.js",
  "static/chunks/0b624703d15853ab.js",
  "static/chunks/7002ffa4e3ada4ac.js",
  "static/chunks/19fdc79edbcdc5f0.css",
  "static/chunks/turbopack-71e0d5230120b34d.js"
])
