self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/3b837bada6eada40.js"
  ],
  "/_error": [
    "static/chunks/99a4c814ef7d1e9f.js"
  ],
  "/api-docs": [
    "static/chunks/33a44af28b2e2903.js"
  ],
  "/audit-logs": [
    "static/chunks/422848f4de6d2465.js"
  ],
  "/login": [
    "static/chunks/ef5d3f384f2e6804.js"
  ],
  "/settings": [
    "static/chunks/ec9f1ebe17d269f6.js"
  ],
  "/tokens": [
    "static/chunks/f10197f652fa82ed.js"
  ],
  "/versions": [
    "static/chunks/00063754ebe6e0db.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/audit-logs",
    "/api/audit-logs/[id]",
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/me",
    "/api/hello",
    "/api/settings",
    "/api/software",
    "/api/software/[id]",
    "/api/tokens",
    "/api/tokens/validate/[token]",
    "/api/tokens/[id]",
    "/api/upload",
    "/api/users",
    "/api/users/[id]",
    "/api/users/[id]/permissions",
    "/api/users/[id]/permissions/[permissionId]",
    "/api/versions",
    "/api/versions/[id]",
    "/api-docs",
    "/audit-logs",
    "/login",
    "/settings",
    "/tokens",
    "/versions"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()