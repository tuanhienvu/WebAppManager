globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/7a34bb1fa340396b.js",
      "static/chunks/703451e762e00579.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/turbopack-ffd3566131617199.js"
    ],
    "/_app": [
      "static/chunks/b0ad044e9531f801.js",
      "static/chunks/42dc5ea08fc980c5.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/19fdc79edbcdc5f0.css",
      "static/chunks/turbopack-71e0d5230120b34d.js"
    ],
    "/_error": [
      "static/chunks/7f84e238cf01cacf.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/turbopack-f4e1c98853a69c1a.js"
    ],
    "/api-docs": [
      "static/chunks/79853526f4a3dbd5.js",
      "static/chunks/703451e762e00579.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/6c804ac4ce966313.css",
      "static/chunks/turbopack-905caac1449edc9d.js"
    ],
    "/audit-logs": [
      "static/chunks/9ad373a50c4973e2.js",
      "static/chunks/703451e762e00579.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/turbopack-6bd715b5d438246e.js"
    ],
    "/login": [
      "static/chunks/ef2a36a82d72f307.js",
      "static/chunks/731d714d75201630.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/turbopack-a2f05df369e12ccb.js"
    ],
    "/settings": [
      "static/chunks/07ca223b8a905559.js",
      "static/chunks/703451e762e00579.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/turbopack-82ee580cef3c0464.js"
    ],
    "/tokens": [
      "static/chunks/fb7596f6214a4949.js",
      "static/chunks/703451e762e00579.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/turbopack-082b498e74452639.js"
    ],
    "/versions": [
      "static/chunks/1e3c5a959bb4b67f.js",
      "static/chunks/703451e762e00579.js",
      "static/chunks/0b624703d15853ab.js",
      "static/chunks/7002ffa4e3ada4ac.js",
      "static/chunks/turbopack-12f89edddb475c35.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];