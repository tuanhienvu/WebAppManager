var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__82e7a549._.js")
R.c("server/chunks/ssr/src_pages__app_tsx_f993d483._.js")
R.m(68695)
module.exports=R.m(68695).exports
