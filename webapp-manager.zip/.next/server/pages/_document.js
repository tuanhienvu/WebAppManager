var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__8553a275._.js")
R.c("server/chunks/ssr/[root-of-the-server]__537a23c6._.js")
R.m(17359)
module.exports=R.m(17359).exports
