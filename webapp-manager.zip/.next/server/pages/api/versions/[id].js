var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/versions/[id].js")
R.c("server/chunks/[root-of-the-server]__0059c38a._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(58675)
module.exports=R.m(58675).exports
