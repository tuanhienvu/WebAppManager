var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/software/[id].js")
R.c("server/chunks/[root-of-the-server]__7d31912c._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(54149)
module.exports=R.m(54149).exports
