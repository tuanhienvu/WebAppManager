var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/versions.js")
R.c("server/chunks/[root-of-the-server]__3b9c09b3._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(58514)
module.exports=R.m(58514).exports
