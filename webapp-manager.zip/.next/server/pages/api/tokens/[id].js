var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/tokens/[id].js")
R.c("server/chunks/[root-of-the-server]__8d713f42._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(53338)
module.exports=R.m(53338).exports
