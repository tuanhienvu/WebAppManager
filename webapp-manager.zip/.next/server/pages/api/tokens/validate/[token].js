var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/tokens/validate/[token].js")
R.c("server/chunks/[root-of-the-server]__00872f78._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(16156)
module.exports=R.m(16156).exports
