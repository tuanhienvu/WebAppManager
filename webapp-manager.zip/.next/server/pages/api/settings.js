var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/settings.js")
R.c("server/chunks/[root-of-the-server]__c4c4274c._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(36243)
module.exports=R.m(36243).exports
