var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/users/[id].js")
R.c("server/chunks/[root-of-the-server]__6d7b9a0b._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(97880)
module.exports=R.m(97880).exports
