var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/pages/api/users/[id]/permissions/[permissionId].js")
R.c("server/chunks/[root-of-the-server]__ed1ae130._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(81633)
module.exports=R.m(81633).exports
