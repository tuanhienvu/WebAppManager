var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/users/[id]/permissions.js")
R.c("server/chunks/[root-of-the-server]__07fbc084._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(66258)
module.exports=R.m(66258).exports
