var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/me.js")
R.c("server/chunks/[root-of-the-server]__09413859._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(74959)
module.exports=R.m(74959).exports
