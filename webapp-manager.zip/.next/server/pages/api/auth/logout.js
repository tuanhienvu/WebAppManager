var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/logout.js")
R.c("server/chunks/[root-of-the-server]__08e8c4b5._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(27938)
module.exports=R.m(27938).exports
