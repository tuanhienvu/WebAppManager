var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/audit-logs/[id].js")
R.c("server/chunks/[root-of-the-server]__8fb6930f._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(36698)
module.exports=R.m(36698).exports
