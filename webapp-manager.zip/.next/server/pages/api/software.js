var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/software.js")
R.c("server/chunks/[root-of-the-server]__d5184f84._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(29731)
module.exports=R.m(29731).exports
