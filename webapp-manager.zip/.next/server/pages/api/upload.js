var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/upload.js")
R.c("server/chunks/[root-of-the-server]__261757c0._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(47615)
module.exports=R.m(47615).exports
