var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/hello.js")
R.c("server/chunks/[root-of-the-server]__c1750b75._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(18894)
module.exports=R.m(18894).exports
