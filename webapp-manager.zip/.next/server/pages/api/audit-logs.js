var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/audit-logs.js")
R.c("server/chunks/[root-of-the-server]__b8006f58._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(42019)
module.exports=R.m(42019).exports
