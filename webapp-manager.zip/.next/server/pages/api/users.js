var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/users.js")
R.c("server/chunks/[root-of-the-server]__c769368a._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(63748)
module.exports=R.m(63748).exports
