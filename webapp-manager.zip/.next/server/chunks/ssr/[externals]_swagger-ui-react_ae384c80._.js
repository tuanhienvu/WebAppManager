module.exports=[17510,a=>a.a(async(b,c)=>{try{let b=await a.y("swagger-ui-react");a.n(b),c()}catch(a){c(a)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_swagger-ui-react_ae384c80._.js.map