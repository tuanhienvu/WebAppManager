module.exports=[22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},38224,a=>{a.v(b=>Promise.all(["server/chunks/ssr/[externals]_swagger-ui-react_ae384c80._.js"].map(b=>a.l(b))).then(()=>b(17510)))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__cfb843b4._.js.map