export interface CompanySettings {
  companyName?: string;
  slogan?: string;
  logo?: string;
  address?: string;
  email?: string;
  phone?: string;
  mobile?: string;
}

